
package pkg3.pkg12.pkg2;

public class Main {

    public static void main(String[] args) {
        System.out.println("TABLA DE MULTIPLICAR DE 5");

        for (int i = 1; i < 11; i++) {
            System.out.println(i + "*" + 5 + " = " + (i * 5));
        }

    }

}
