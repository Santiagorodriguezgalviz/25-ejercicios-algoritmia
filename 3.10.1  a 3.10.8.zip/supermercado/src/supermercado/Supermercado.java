/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package supermercado;
import java.util.Scanner;
/**
 *
 * @author Ambiente 209-1
 */
public class Supermercado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner scan = new Scanner(System.in);
        double totalCompra = 0;
        String respuesta;
        
        do {
            System.out.print("Ingrese el precio del artículo: ");
            double precio = scan.nextDouble();
            System.out.print("Ingrese la cantidad de artículos que tomó: ");
            int cantidad = scan.nextInt();
            double subtotal = precio * cantidad;
            totalCompra += subtotal;
            
            System.out.print("¿Desea agregar otro artículo? (S/N): ");
            respuesta = scan.next();
            
        } while (respuesta.equalsIgnoreCase("S"));
        
        System.out.println("El total de su compra es: $" + totalCompra);

    }

}
   
